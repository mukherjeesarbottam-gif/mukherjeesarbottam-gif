<div align="center">

<!-- =========================================================
     GAMIFIED CODING HERO
     Local GIF = reliable GitHub README rendering.
     Upload assets/coding-character.gif together with this README.
     ========================================================= -->

<img src="./assets/coding-character.gif"
     width="780"
     alt="Animated gamified developer coding at a futuristic workstation"/>

<br/>

<img src="https://readme-typing-svg.demolab.com?font=Orbitron&weight=800&size=20&duration=2600&pause=900&color=00F0FF&center=true&vCenter=true&width=650&height=48&lines=%F0%9F%A4%96+AI%2FML+ENGINEER;%F0%9F%94%90+CYBERSECURITY+ENTHUSIAST;%E2%9A%A1+DEEP+LEARNING+%2B+EXPLAINABLE+AI;%F0%9F%9B%A1%EF%B8%8F+INTELLIGENT+THREAT+DETECTION;%F0%9F%8C%90+AI-POWERED+WEB+APPLICATIONS"
     alt="Animated developer roles"/>

<br/>

<a href="https://github.com/mukherjeesarbottam-gif">
  <img src="https://img.shields.io/badge/GitHub-050914?style=for-the-badge&logo=github&logoColor=00F0FF" alt="GitHub"/>
</a>
&nbsp;
<a href="https://www.linkedin.com/in/sarbottam-mukherjee-8647342a0">
  <img src="https://img.shields.io/badge/LinkedIn-050914?style=for-the-badge&logo=linkedin&logoColor=8A2BE2" alt="LinkedIn"/>
</a>
&nbsp;
<a href="https://mailshield-frontend.onrender.com/">
  <img src="https://img.shields.io/badge/MailShield-050914?style=for-the-badge&logo=render&logoColor=00F0FF" alt="MailShield"/>
</a>
&nbsp;
<a href="https://exampro-9398b.web.app/">
  <img src="https://img.shields.io/badge/ExamPro-050914?style=for-the-badge&logo=firebase&logoColor=8A2BE2" alt="ExamPro"/>
</a>

<br/><br/>

<code>🎮 PLAYER: DEVELOPER</code>
&nbsp; <code>⚡ XP: BUILDING</code>
&nbsp; <code>🛡️ MODE: CYBER AI</code>

</div>

---

# 👋 Hello, I'm Sarbottam

<div align="center">

### 🤖 AI/ML Engineer &nbsp;•&nbsp; 🔐 Cybersecurity Enthusiast &nbsp;•&nbsp; 🌐 Developer

</div>

I work at the intersection of **artificial intelligence, cybersecurity, and modern web engineering**. My focus is on building practical systems for automated threat detection, machine-learning inference, NLP, computer vision, explainable AI, and secure data processing.

I enjoy turning complex technical ideas into usable applications — from network-security pipelines and ML classifiers to responsive, interactive web experiences.

---

## 🧭 What I Do

<table width="100%">
<tr>
<td width="50%" valign="top">

### 🤖 AI / ML Engineering

- Classification & anomaly detection
- XGBoost & Scikit-learn workflows
- Deep learning & model inference
- Explainable AI with SHAP
- NLP pipelines

</td>
<td width="50%" valign="top">

### 🔐 Cybersecurity

- Network traffic analysis
- Threat detection
- Zeek analytics
- Security alert scoring
- SIEM concepts & security automation

</td>
</tr>
<tr>
<td width="50%" valign="top">

### 🌐 Full-Stack / Web

- React & TypeScript
- Node.js & Express
- Firebase
- Responsive UI/UX
- Three.js & interactive web visuals

</td>
<td width="50%" valign="top">

### 👁️ Computer Vision

- CNN architectures
- Image classification
- Computer vision pipelines
- AI-generated image detection
- Deepfake verification research

</td>
</tr>
</table>

---

# 🏆 Featured Projects

## 🛡️ ANVEX
### AI-Powered Cyber Threat Detection

> **Role:** AI/ML & Threat Engine Lead

An intelligent network-security pipeline designed to detect and score modern cyber threats using machine learning, anomaly detection, network features, and Zeek telemetry.

**Core work**

- Built a **13-feature network representation**.
- Implemented an **XGBoost multiclass classifier**.
- Integrated an **Isolation Forest anomaly detector**.
- Developed detection logic for:
  - DDoS
  - Port Scan
  - DGA
  - C2 Beacon
  - Exfiltration
- Integrated **Zeek logs** for network telemetry.
- Added **SHAP explainability** and dynamic threat severity scoring.

<p align="center">
<img src="https://img.shields.io/badge/Python-02040A?style=for-the-badge&logo=python&logoColor=3776AB" alt="Python"/>
<img src="https://img.shields.io/badge/XGBoost-02040A?style=for-the-badge&logo=python&logoColor=00F0FF" alt="XGBoost"/>
<img src="https://img.shields.io/badge/Zeek-02040A?style=for-the-badge&logo=wireshark&logoColor=00F0FF" alt="Zeek"/>
<img src="https://img.shields.io/badge/SHAP-02040A?style=for-the-badge&logo=python&logoColor=8A2BE2" alt="SHAP"/>
</p>

---

## 📩 MAILSHIELD
### Intelligent Email Spam Detection

> **Role:** AI/ML & NLP Engineer

An NLP-powered email classification system designed to identify and filter spam using machine-learning and text-processing techniques.

**Core work**

- Designed the end-to-end spam detection pipeline.
- Built text preprocessing and feature extraction.
- Used **TF-IDF vectorization**.
- Added URL threat indicators.
- Implemented **LinearSVC** classification.
- Connected a **FastAPI** backend with a responsive React/TypeScript interface.

<p align="center">
<a href="https://github.com/mukherjeesarbottam-gif/MAILSHIELD">
<img src="https://img.shields.io/badge/Repository-00F0FF?style=for-the-badge&logo=github&logoColor=black" alt="MailShield repository"/>
</a>
<a href="https://mailshield-frontend.onrender.com/">
<img src="https://img.shields.io/badge/Live%20Demo-8A2BE2?style=for-the-badge&logo=render&logoColor=white" alt="MailShield live demo"/>
</a>
</p>

---

## 📝 EXAMPRO
### Interactive Online Examination System

> **Role:** Web Application Developer

An interactive examination platform focused on engaging UI, authentication, real-time application state, and cloud-backed workflows.

**Core work**

- Designed the interactive web interface.
- Built HTML5/CSS3/JavaScript components.
- Integrated **Three.js** visual assets.
- Implemented **Firebase Authentication**.
- Structured **Firestore** data workflows.
- Integrated Firebase hosting.

<p align="center">
<a href="https://github.com/mukherjeesarbottam-gif/Exampro">
<img src="https://img.shields.io/badge/Repository-00F0FF?style=for-the-badge&logo=github&logoColor=black" alt="ExamPro repository"/>
</a>
<a href="https://exampro-9398b.web.app/">
<img src="https://img.shields.io/badge/Live%20Demo-8A2BE2?style=for-the-badge&logo=firebase&logoColor=white" alt="ExamPro live demo"/>
</a>
</p>

---

# ⚔️ Tech Stack

<div align="center">

### Languages
<img src="https://skillicons.dev/icons?i=py,java,c,js,ts&theme=dark" alt="Python Java C JavaScript TypeScript"/>

### AI / ML
<img src="https://skillicons.dev/icons?i=pytorch,tensorflow,sklearn,opencv,fastapi&theme=dark" alt="PyTorch TensorFlow Scikit-learn OpenCV FastAPI"/>

### Web
<img src="https://skillicons.dev/icons?i=html,css,react,nodejs,express,threejs&theme=dark" alt="HTML CSS React Node Express Three.js"/>

### Cloud / Data / Tools
<img src="https://skillicons.dev/icons?i=firebase,mongodb,postman,git,github,vscode,linux,docker&theme=dark" alt="Firebase MongoDB Postman Git GitHub VS Code Linux Docker"/>

</div>

---

# 🧪 Currently Exploring

<div align="center">

`Zeek Network Security`
&nbsp; • &nbsp;
`Apache Kafka Streaming`
&nbsp; • &nbsp;
`SIEM Analytics`
&nbsp; • &nbsp;
`LLM Security`
&nbsp; • &nbsp;
`Red Teaming`
&nbsp; • &nbsp;
`Real-Time Anomaly Detection`

</div>

---

# 📊 GitHub Analytics

<div align="center">

<a href="https://github.com/mukherjeesarbottam-gif">
<img src="https://github-readme-stats-eight-theta.vercel.app/api?username=mukherjeesarbottam-gif&show_icons=true&theme=tokyonight&hide_border=true&title_color=00F0FF&icon_color=8A2BE2&text_color=a9b1d6"
     width="82%"
     alt="GitHub statistics"/>
</a>

<br/><br/>

<a href="https://github.com/mukherjeesarbottam-gif">
<img src="https://github-readme-streak-stats.herokuapp.com/?user=mukherjeesarbottam-gif&theme=tokyonight&hide_border=true&background=050914&stroke=00F0FF&ring=8A2BE2&fire=00F0FF&currStreakLabel=00F0FF"
     width="82%"
     alt="GitHub contribution streak"/>
</a>

<br/><br/>

<a href="https://github.com/mukherjeesarbottam-gif">
<img src="https://github-readme-stats-eight-theta.vercel.app/api/top-langs/?username=mukherjeesarbottam-gif&layout=compact&theme=tokyonight&hide_border=true&title_color=00F0FF&text_color=a9b1d6"
     width="65%"
     alt="Top programming languages"/>
</a>

</div>

---

# 🌐 Connect

<div align="center">

<a href="https://github.com/mukherjeesarbottam-gif">
  <img src="https://img.shields.io/badge/GitHub-050914?style=for-the-badge&logo=github&logoColor=00F0FF" alt="GitHub"/>
</a>
&nbsp;
<a href="https://www.linkedin.com/in/sarbottam-mukherjee-8647342a0">
  <img src="https://img.shields.io/badge/LinkedIn-050914?style=for-the-badge&logo=linkedin&logoColor=8A2BE2" alt="LinkedIn"/>
</a>

<br/><br/>

<code>┌────────────────────────────────────────────┐</code><br/>
<code>│  BUILD  •  EXPERIMENT  •  LEARN  •  SHIP │</code><br/>
<code>└────────────────────────────────────────────┘</code>

</div>

<br/>

<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:7B2CBF,50:172554,100:050914&height=85&section=footer"
     width="100%"
     alt="Profile footer"/>

</div>
